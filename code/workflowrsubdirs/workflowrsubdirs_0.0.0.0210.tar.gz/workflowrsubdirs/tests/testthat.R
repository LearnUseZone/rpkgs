library(testthat)
library(workflowrsubdirs)

test_check("workflowrsubdirs")
